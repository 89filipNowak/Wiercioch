# Sticky Slider Navigation (Responsive)

A Pen created on CodePen.io. Original URL: [https://codepen.io/ettrics/pen/WRbGRN](https://codepen.io/ettrics/pen/WRbGRN).

Navigation bar that sticks as you scroll, animating a slider which indicates the page section you are currently looking at. Written with SCSS, Javascript, and JQuery.